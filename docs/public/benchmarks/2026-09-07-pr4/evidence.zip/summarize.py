#!/usr/bin/env python3
import collections,json,pathlib,statistics,subprocess,os,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'evidence'
rows=[json.loads(x) for x in (OUT/'process.jsonl').read_text().splitlines()]
assert len(rows)==56, len(rows)
groups=collections.defaultdict(list)
for r in rows:
    groups[(r['case'],r['version'])].append(r)
assert len(groups)==8
for key, rs in groups.items():
    assert sorted(r['round'] for r in rs)==list(range(7)),key
    assert len({r['config_sha256'] for r in rows if r['case']==key[0]})==1,key
    for r in rs:
        for phase in r['phases'].values():
            assert all(x['VmSwap']==0 for x in phase['samples'])
summary=[]
for case in ('idle','tcp100','tcp1000','dns4096'):
    phases=groups[(case,'before')][0]['phases']
    for phase in phases:
        item={'case':case,'phase':phase}
        for v in ('before','after'):
            rs=groups[(case,v)]
            vals=[r['phases'][phase]['median_kib']['VmRSS']/1024 for r in rs]
            hwm=[r['phases'][phase]['median_kib']['VmHWM']/1024 for r in rs]
            item[v]={'rss_mib':statistics.median(vals),'min':min(vals),'max':max(vals),'hwm_mib':statistics.median(hwm)}
        item['change_percent']=(item['after']['rss_mib']/item['before']['rss_mib']-1)*100
        summary.append(item)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
env=dict(os.environ,GOTOOLCHAIN='local')
for case in ('idle','tcp1000','dns4096'):
    for v in ('before','after'):
        result=subprocess.run(['go','tool','pprof','-top','-nodecount=8','-sample_index=inuse_space',str(ROOT/v/'aster-core'),str(OUT/f'{case}-{v}.heap')],env=env,capture_output=True,text=True,check=True)
        (OUT/f'{case}-{v}-heap-top.txt').write_text(result.stdout+result.stderr)
# Same benchmark implementations must be verified, not merely assumed.
for pkg in ('dns/resolver_lookup_test.go','common/net/relay_comparison_test.go'):
    sources=[]
    for v in ('before','after'):
        text=(ROOT/v/pkg).read_text()
        sources.append(text[text.index('func Benchmark'):].split('\nfunc Test',1)[0].rstrip())
    assert sources[0]==sources[1],pkg
    (OUT/(pathlib.Path(pkg).stem+'-bench-source.txt')).write_text(sources[0])
print('PASS: 56 fresh processes, seven rounds, same per-case configs, zero swap, identical benchmark implementations')
