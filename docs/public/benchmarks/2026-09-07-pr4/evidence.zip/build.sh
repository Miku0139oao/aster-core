#!/bin/bash
set -euo pipefail
cd /root/aster-validation-20260907
cp /mnt/d/vless/aster-validation-20260907/{run.py,micro.py,pool_validation_test.go} .
export GOTOOLCHAIN=local GOMAXPROCS=4 GOAMD64=v1 CGO_ENABLED=0
for v in before after; do
 cp pool_validation_test.go "$v/common/pool/validation_bench_test.go"
 gofmt -w "$v/common/pool/validation_bench_test.go"
 (cd "$v"
 go build -trimpath -ldflags='-s -w' -o aster-core .
 go test -c -o pool.test ./common/pool
 go test -c -o dns.test ./dns
 go test -c -o net.test ./common/net)
done
sha256sum before/{aster-core,pool.test,dns.test,net.test} after/{aster-core,pool.test,dns.test,net.test} > evidence/binary-sha256.txt
cp run.py micro.py pool_validation_test.go /mnt/d/vless/aster-validation-20260907/build.sh evidence/
python3 micro.py
