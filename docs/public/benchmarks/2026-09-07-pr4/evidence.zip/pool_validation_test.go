package pool

import (
 "fmt"
 "testing"
)

// Identical benchmark-only source is added to both isolated revision trees.
func BenchmarkValidationAllocator(b *testing.B) {
 for _, size := range []int{8192, 16384, 32768, 131072} {
  b.Run(fmt.Sprint(size), func(b *testing.B) {
   alloc := NewAllocator()
   buf := alloc.Get(size)
   if err := alloc.Put(buf); err != nil { b.Fatal(err) }
   b.ReportAllocs()
   b.ResetTimer()
   for i := 0; i < b.N; i++ {
    buf := alloc.Get(size)
    buf[0] = byte(i)
    if err := alloc.Put(buf); err != nil { b.Fatal(err) }
   }
  })
 }
}
