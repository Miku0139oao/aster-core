# 2026-09-07 PR #4 validation evidence

## Scope

Before: be6d79129f2ee44524ce1d0796f12133e3acf25e
After: c5f553dc7dab4954260b8ae96f6057e581447ade

Core production sources were not modified. These revisions were exported with `git archive` into separate Linux trees. Only the identical allocator benchmark-only file was added to each tree. The DNS and relay benchmark functions are byte-identical across revisions (verified by summarize.py); the surrounding test files need not be identical.

Host: Arch Linux under WSL2 on Ryzen 9 5900X, 24 logical CPUs. See environment.txt. No CPU affinity or fixed clock; this is a development host, not OpenWrt/WAN. Native toolchain: go1.26.5-X:nodwarf5. Tests used CGO_ENABLED=1; benchmark/core binaries used CGO_ENABLED=0, GOAMD64=v1. Whole core: -trimpath -ldflags='-s -w'.

## Contents

- process.jsonl: final 56 new processes, four scenarios, seven runs per revision, alternating order. Includes config hashes, phase samples, RSS/high-water mark/swap in KiB, and verified DNS upstream counts.
- summary.json: medians/ranges from the final cohort. Every sampled VmSwap is zero.
- bench-before.txt / bench-after.txt: eight benchmark cases, seven fresh processes per case/revision; -test.cpu=1 -test.benchtime=2s. Total 112 processes.
- bench-invocations.jsonl: commands and individual outputs.
- benchstat.txt: statistical comparison, no multiple-comparison correction.
- *.heap / *-heap-top.txt: six separate diagnostic processes, not part of the RSS cohort. Profiles use gc=0. Default heap sampling and natural GC leave the TCP profile dominated by initialization, insufficient for current per-connection attribution.
- *.log: synthetic loopback workload logs. Runs numbered 99 are profile-only diagnostics.
- linux-test-retry.txt / linux-low-test.txt: successful normal and low-memory full suites. Original linux-test.txt records the initial 180-second timeout; the normal retry allowed ten minutes and listener/inbound took 209.051 seconds. Tests were not edited or filtered to pass.
- linux-race.txt: normal and low-memory pool/DNS race results.
- linux-vet.txt / linux-build.txt: empty successful output from commands run under `set -e`; failures would have stopped the validation command.
- binary-sha256.txt: measured binaries, which are deliberately NOT distributed in this archive.
- run.py, micro.py, pool_validation_test.go, build.sh, summarize.py: harnesses and analysis.
- configs/: one final config per scenario. Both revisions and all rounds used the same per-scenario SHA256.
- pilot/: excluded probes. The first harness used 127.0.0.1 clients and hit a source-AddrPort loop-detection collision with 1,000 local TCP connections. The final harness binds clients to 127.0.0.2. Early profiles were captured inside the RSS cohort; all idle/TCP samples were rerun without profiling. A DNS pilot left global IPv6 disabled and failed AAAA validation; only the DNS config was corrected and that entire scenario rerun. The final script's idle/TCP configurations and measurement behavior match the completed cohort.

## Whole-process method

GOMAXPROCS=2; GOGC/GOMEMLIMIT removed from environment; no forced GC. Rule + MATCH,DIRECT, TUN disabled, loopback-only listeners. Debug controller enabled, no log WebSocket subscriber. DNS and global IPv6 enabled only for the DNS scenario.

TCP: an external Python echo server, validated SOCKS handshake and echo for every connection, exact controller connection count, then 15-second settling and 12 samples at 250 ms. Transfer 128 x 4096 bytes per direction per connection using at most 16 workers. Sample again, close connections, verify controller count zero, wait 60 seconds, sample again. Linux VmRSS does not include all kernel socket/splice-pipe memory.

DNS: local synthetic upstream, 4096 unique names, alternating A/AAAA, TTL=3600, LRU capacity=8192. Two query passes verify 4096 cold upstream requests and zero warm requests. Wait 15 seconds, then sample as above. No cache-capacity reduction.

## Reproduction (Linux)

The scripts use their own parent directory as ROOT, except build.sh, whose paths reflect this recorded run. Prepare an equivalent isolated directory; adjust build.sh's source-copy paths if needed. Keep both revision trees and evidence/ under ROOT. Do not mix a rerun into existing *.jsonl or benchmark output files: archive old output first.

```sh
ROOT=/root/aster-validation-20260907
mkdir -p "$ROOT"/{before,after,evidence}
git archive be6d79129f2ee44524ce1d0796f12133e3acf25e | tar -x -C "$ROOT/before"
git archive c5f553dc7dab4954260b8ae96f6057e581447ade | tar -x -C "$ROOT/after"
# Copy run.py, micro.py, summarize.py and pool_validation_test.go from this archive to ROOT.
cd "$ROOT"
export GOTOOLCHAIN=local GOAMD64=v1 CGO_ENABLED=0 GOMAXPROCS=4
unset GOGC GOMEMLIMIT
for v in before after; do
  cp pool_validation_test.go "$v/common/pool/validation_bench_test.go"
  (cd "$v"
   gofmt -w common/pool/validation_bench_test.go
   go build -trimpath -ldflags='-s -w' -o aster-core .
   go test -c -o pool.test ./common/pool
   go test -c -o dns.test ./dns
   go test -c -o net.test ./common/net)
done
python3 micro.py
python3 run.py
python3 run.py --profiles
python3 summarize.py
benchstat evidence/bench-before.txt evidence/bench-after.txt
```

Reserve loopback ports 28790-28794. The driver raises its own soft file-descriptor limit up to 65536, within the existing hard limit. It never changes global network/kernel settings. The full-process cohort takes roughly 45 minutes or more; no build/test workload should run concurrently.

Linux verification commands, run in the after tree with GOTOOLCHAIN=local, GOMAXPROCS=4 and CGO_ENABLED=1:

```sh
go test -p=4 -count=1 -timeout=10m ./...
go test -p=4 -tags with_low_memory -count=1 -timeout=10m ./...
go test -race -count=1 -timeout=3m ./common/pool ./dns
go test -race -tags with_low_memory -count=1 -timeout=3m ./common/pool ./dns
go vet ./...
go build ./...
go build -tags with_low_memory ./...
```

Windows Go 1.26.3 verification was performed before this Linux cohort: complete normal/low-memory tests and builds, changed-package race tests in both modes, go vet, changed-Go-file gofmt, golangci-lint (zero issues). These Windows results are transcript-verified, not represented by the Linux log files.

## Interpretation limits

All RSS ranges overlap. DNS median RSS is about 1.10 MiB lower, while TCP-1000 median RSS increases and neither revision returns to idle after 60 seconds. Large-pool operations and full-message DNS cache hits regress in these microbenchmarks; no silent production-code fix was applied. IPv4 lookup and relay timing are not significantly different. No Windows/Linux memory-metric equivalence, download-speed promise, or OS-memory reclamation claim.

Not measured: Linux TLS-proxy/WAN, OpenWrt, queued UDP pressure, low-memory-mode performance, or full-process allocator-burst retention limits. The future optimization plan, including P0-1 attribution, remains separate work.
