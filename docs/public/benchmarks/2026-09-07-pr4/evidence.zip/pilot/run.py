#!/usr/bin/env python3
"""Linux full-process A/B; only loopback traffic, no forced GC or GC tuning."""
import asyncio, concurrent.futures, hashlib, json, os, pathlib, resource, signal, socket, statistics, struct, subprocess, time, urllib.request
ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / 'evidence'
OUT.mkdir(exist_ok=True)
ENV = dict(os.environ, GOMAXPROCS='2')
for key in ('GOGC', 'GOMEMLIMIT'): ENV.pop(key, None)
resource.setrlimit(resource.RLIMIT_NOFILE, (min(65536, resource.getrlimit(resource.RLIMIT_NOFILE)[1]), resource.getrlimit(resource.RLIMIT_NOFILE)[1]))

def digest(data): return hashlib.sha256(data).hexdigest()
def http(port, route):
    with urllib.request.urlopen(f'http://127.0.0.1:{port}{route}', timeout=10) as r: return r.read()
def stats(pid):
    values = {}
    for line in pathlib.Path(f'/proc/{pid}/status').read_text().splitlines():
        if line.startswith(('VmRSS:', 'VmHWM:', 'VmSwap:')):
            k, v, _ = line.split(); values[k[:-1]] = int(v)
    return values
async def sample(pid):
    points = []
    for _ in range(12):
        points.append(stats(pid)); await asyncio.sleep(.25)
    return {'median_kib': {k: statistics.median(p[k] for p in points) for k in points[0]}, 'samples': points}
async def echo(reader, writer):
    try:
        while data := await reader.read(65536):
            writer.write(data); await writer.drain()
    except (ConnectionError, asyncio.CancelledError): pass
    finally:
        writer.close()
        try: await writer.wait_closed()
        except ConnectionError: pass
class DNS(asyncio.DatagramProtocol):
    queries = 0
    def connection_made(self, transport): self.transport = transport
    def datagram_received(self, data, addr):
        pos = 12
        while data[pos]: pos += data[pos] + 1
        pos += 1
        typ = struct.unpack('!H', data[pos:pos+2])[0]
        question = data[12:pos+4]
        ip = socket.inet_pton(socket.AF_INET if typ == 1 else socket.AF_INET6, '192.0.2.1' if typ == 1 else '2001:db8::1')
        header = data[:2] + struct.pack('!HHHHH', 0x8180, 1, 1, 0, 0)
        answer = b'\xc0\x0c' + struct.pack('!HHIH', typ, 1, 3600, len(ip)) + ip
        self.queries += 1; self.transport.sendto(header + question + answer, addr)

def prime_dns(port):
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
        s.settimeout(3)
        for i in range(4096):
            name = f'entry{i}.validation.test'
            wire = b''.join(bytes([len(x)]) + x.encode() for x in name.split('.')) + b'\x00'
            typ = 1 if i % 2 == 0 else 28
            q = struct.pack('!HHHHHH', i, 0x100, 1, 0, 0, 0) + wire + struct.pack('!HH', typ, 1)
            s.sendto(q, ('127.0.0.1', port)); reply = s.recv(4096)
            assert reply[:2] == q[:2] and reply[3] & 15 == 0 and struct.unpack('!H', reply[6:8])[0] == 1

async def open_socks(port, target):
    r, w = await asyncio.open_connection('127.0.0.1', port)
    w.write(b'\x05\x01\x00'); await w.drain()
    assert await r.readexactly(2) == b'\x05\x00'
    w.write(b'\x05\x01\x00\x01\x7f\x00\x00\x01' + struct.pack('!H', target)); await w.drain()
    head = await r.readexactly(4); assert head[1] == 0
    if head[3] == 1: await r.readexactly(6)
    elif head[3] == 4: await r.readexactly(18)
    else: raise AssertionError(head)
    w.write(b'validation'); await w.drain(); assert await r.readexactly(10) == b'validation'
    return r, w
async def one(case, version, iteration, echo_port, dns_server, dns_protocol):
    label = f'{case}-{version}-{iteration}'
    home = ROOT / 'runs' / label; home.mkdir(parents=True, exist_ok=True)
    socks, control, dns_port = 28790, 28791, 28792
    config = f'''socks-port: {socks}
bind-address: 127.0.0.1
allow-lan: false
mode: rule
log-level: debug
ipv6: false
external-controller: 127.0.0.1:{control}
profile:
  store-selected: false
  store-fake-ip: false
tun:
  enable: false
dns:
  enable: {'true' if case == 'dns4096' else 'false'}
  listen: 127.0.0.1:{dns_port}
  ipv6: true
  enhanced-mode: redir-host
  cache-algorithm: lru
  cache-max-size: 8192
  use-hosts: false
  nameserver:
    - udp://127.0.0.1:{dns_server}
rules:
  - MATCH,DIRECT
'''
    (home / 'config.yaml').write_text(config)
    record = {'case': case, 'version': version, 'round': iteration, 'config_sha256': digest(config.encode()), 'phases': {}}
    with (OUT / f'{label}.log').open('wb') as log:
        p = subprocess.Popen([str(ROOT/version/'aster-core'), '-d', str(home), '-f', str(home/'config.yaml')], env=ENV, stdout=log, stderr=log)
        conns = []
        try:
            for _ in range(200):
                if p.poll() is not None: raise RuntimeError(f'{label} exited: {p.returncode}')
                try:
                    await asyncio.to_thread(http, control, '/version'); break
                except Exception: await asyncio.sleep(.1)
            else: raise RuntimeError('readiness timeout')
            if case.startswith('tcp'):
                count = int(case[3:]); sem = asyncio.Semaphore(16)
                async def connect():
                    async with sem: return await asyncio.wait_for(open_socks(socks, echo_port), 20)
                conns = await asyncio.gather(*(connect() for _ in range(count)))
                live = json.loads(await asyncio.to_thread(http, control, '/connections'))
                assert len(live['connections']) == count
            elif case == 'dns4096':
                begin = dns_protocol.queries
                await asyncio.to_thread(prime_dns, dns_port)
                cold = dns_protocol.queries - begin
                await asyncio.to_thread(prime_dns, dns_port)
                warm = dns_protocol.queries - begin - cold
                assert cold == 4096 and warm == 0, (cold, warm)
                record['upstream_queries'] = {'cold': cold, 'warm': warm}
            await asyncio.sleep(15)
            record['phases']['held' if conns else 'steady'] = await sample(p.pid)
            # gc=0 is explicit. Runtime's sampled heap view may lag the current heap.
            if iteration == 0:
                profile = await asyncio.to_thread(http, control, '/debug/pprof/heap?gc=0')
                (OUT / f'{case}-{version}.heap').write_bytes(profile)
            if conns:
                sem = asyncio.Semaphore(16)
                payload = bytes(4096)
                async def transfer(conn):
                    async with sem:
                        r, w = conn
                        for _ in range(128):
                            w.write(payload); await w.drain()
                            assert await r.readexactly(len(payload)) == payload
                start = time.monotonic()
                await asyncio.wait_for(asyncio.gather(*(transfer(c) for c in conns)), 180)
                record['transfer_seconds'] = time.monotonic()-start
                record['bytes_per_direction'] = len(conns)*128*4096
                record['phases']['after_transfer'] = await sample(p.pid)
                for _, w in conns: w.close()
                await asyncio.gather(*(w.wait_closed() for _, w in conns), return_exceptions=True)
                conns = []
                for _ in range(100):
                    live = json.loads(await asyncio.to_thread(http, control, '/connections'))
                    if len(live.get('connections') or []) == 0: break
                    await asyncio.sleep(.1)
                else: raise AssertionError('connections did not drain')
                await asyncio.sleep(60)
                record['phases']['released60'] = await sample(p.pid)
            assert p.poll() is None
        finally:
            for _, w in conns: w.close()
            p.terminate()
            try: await asyncio.to_thread(p.wait, 10)
            except subprocess.TimeoutExpired: p.kill(); await asyncio.to_thread(p.wait)
    with (OUT/'process.jsonl').open('a') as f: f.write(json.dumps(record)+'\n')
    print(label, {k:v['median_kib']['VmRSS'] for k,v in record['phases'].items()}, flush=True)
async def main():
    server = await asyncio.start_server(echo, '127.0.0.1', 28793)
    transport, protocol = await asyncio.get_running_loop().create_datagram_endpoint(DNS, local_addr=('127.0.0.1',28794))
    try:
        for case in ('idle', 'tcp100', 'tcp1000', 'dns4096'):
            for i in range(7):
                for version in (('before','after') if i%2==0 else ('after','before')):
                    await one(case,version,i,28793,28794,protocol)
    finally:
        transport.close(); server.close(); await server.wait_closed()
if __name__ == '__main__': asyncio.run(main())
