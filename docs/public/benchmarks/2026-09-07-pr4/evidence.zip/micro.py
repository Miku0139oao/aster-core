#!/usr/bin/env python3
import hashlib, json, os, pathlib, subprocess
ROOT=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'evidence'
ENV=dict(os.environ,GOMAXPROCS='1')
for k in ('GOGC','GOMEMLIMIT'): ENV.pop(k,None)
cases=[('pool',f'BenchmarkValidationAllocator/{n}$') for n in (8192,16384,32768,131072)] + [('dns',f'{n}$') for n in ('BenchmarkGetMsgFromCacheHit','BenchmarkExchangeContextCacheHit','BenchmarkLookupIPv4CacheHit')] + [('net','BenchmarkRelay32KiBComparison$')]
for pkg,case in cases:
    for i in range(7):
        for version in (('before','after') if i%2==0 else ('after','before')):
            args=[str(ROOT/version/f'{pkg}.test'),'-test.run=^$',f'-test.bench=^{case}','-test.benchmem','-test.benchtime=2s','-test.cpu=1','-test.count=1']
            result=subprocess.run(args,env=ENV,capture_output=True,text=True,check=True,timeout=90)
            assert 'Benchmark' in result.stdout
            with (OUT/f'bench-{version}.txt').open('a') as f: f.write(result.stdout)
            with (OUT/'bench-invocations.jsonl').open('a') as f: f.write(json.dumps({'package':pkg,'case':case,'round':i,'version':version,'args':args,'output':result.stdout})+'\n')
    print('completed',pkg,case,flush=True)
