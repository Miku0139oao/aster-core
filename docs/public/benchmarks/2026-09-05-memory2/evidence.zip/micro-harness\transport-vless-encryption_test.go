// Identical-source A/B harness; generated from the reviewed candidate.
package encryption

import (
	"encoding/base64"
	"io"
	"net"
	"testing"
	"time"
)

const handshakeTestPadding = "100-35-35"

func plantClientTicket(client *ClientInstance) {
	client.RWLock.Lock()
	client.Expire = time.Now().Add(time.Hour)
	client.PfsKey = make([]byte, 64)
	client.Ticket = make([]byte, 16)
	for i := range client.PfsKey {
		client.PfsKey[i] = byte(i + 1)
	}
	for i := range client.Ticket {
		client.Ticket[i] = byte(i + 17)
	}
	client.RWLock.Unlock()
}

func BenchmarkHandshake0RTTPreWrite(b *testing.B) {
	privB64, pubB64, _, err := GenX25519("")
	if err != nil {
		b.Fatal(err)
	}
	pub, err := base64.RawURLEncoding.DecodeString(pubB64)
	if err != nil {
		b.Fatal(err)
	}
	_ = privB64
	client := &ClientInstance{}
	if err := client.Init([][]byte{pub}, 0, 1, handshakeTestPadding); err != nil {
		b.Fatal(err)
	}
	plantClientTicket(client)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		conn, err := client.Handshake(discardConn{})
		if err != nil {
			b.Fatal(err)
		}
		if len(conn.PreWrite) == 0 {
			b.Fatal("0-RTT PreWrite empty")
		}
	}
}

type discardConn struct {
	net.Conn
}

func (discardConn) Write(p []byte) (int, error) { return len(p), nil }

func (discardConn) Read(p []byte) (int, error) { return 0, io.EOF }

func (discardConn) Close() error { return nil }
