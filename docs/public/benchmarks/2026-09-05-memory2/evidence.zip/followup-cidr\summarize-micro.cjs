const fs=require('fs'),path=require('path');const root=__dirname.replaceAll('\\','/');
const manifest=JSON.parse(fs.readFileSync(root+'/micro-manifest.json','utf8'));
const text={before:'',after:''};const summary=[];let total=0;
function median(a){a=a.slice().sort((a,b)=>a-b);return a[(a.length-1)>>1]}
for(const row of manifest.matrix){
 const cases=JSON.parse(fs.readFileSync(root+'/micro-smoke/'+row.key+'-cases.json','utf8'));
 for(const name of cases.cases){
  const samples={before:[],after:[]};
  for(let round=1;round<=7;round++){for(const label of ['before','after']){
   const file=root+'/micro-raw/'+row.key+'/'+name.replaceAll('/','__')+'/'+round+'-'+label+'.txt';
   const content=fs.readFileSync(file,'utf8');
   const lines=content.split(/\r?\n/).filter(x=>/^Benchmark\S+\s+\d+\s+\S+ ns\/op/.test(x));
   if(lines.length!==1)throw Error('Expected exactly one sample '+file);
   const cols=lines[0].trim().split(/\s+/);if(cols[0].replace(/-1$/,'')!==name)throw Error('Wrong case '+file);
   const parsed={round,iterations:Number(cols[1])};for(let i=2;i+1<cols.length;i+=2)parsed[cols[i+1]]=Number(cols[i]);
   if(!Number.isFinite(parsed['ns/op'])||parsed.iterations<1)throw Error('Bad metrics '+file);
   samples[label].push(parsed);text[label]+=content+'\n';total++;
  }}
  const result={package:row.package,name,samples,metrics:{}};
  for(const metric of ['ns/op','B/op','allocs/op']){
   const b=samples.before.map(x=>x[metric]),a=samples.after.map(x=>x[metric]);
   result.metrics[metric]={before:median(b),after:median(a),beforeMin:Math.min(...b),beforeMax:Math.max(...b),afterMin:Math.min(...a),afterMax:Math.max(...a),changePercent:median(b)?(median(a)/median(b)-1)*100:null};
  }
  summary.push(result);const n=result.metrics['ns/op'],b=result.metrics['B/op'],a=result.metrics['allocs/op'];
  console.log(`${row.package} ${name}: ${n.before} -> ${n.after} ns (${n.changePercent.toFixed(1)}%); ${b.before} -> ${b.after} B; ${a.before} -> ${a.after} allocs`);
 }
}
for(const label of ['before','after'])fs.writeFileSync(root+'/micro-'+label+'.txt',text[label]);
fs.writeFileSync(root+'/micro-summary.json',JSON.stringify({totalSamples:total,cases:summary.length,rounds:7,secondsPerSample:2,note:'Fresh process for each concrete case/sample; GOMAXPROCS=1 and -test.cpu=1; exact same source harness on both revisions. Medians and raw ranges; benchstat supplies significance separately.',results:summary},null,2));
console.log('Verified '+total+' samples / '+summary.length+' cases');
