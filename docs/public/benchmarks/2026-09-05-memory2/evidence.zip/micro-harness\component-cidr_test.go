// Identical-source A/B harness; generated from the reviewed candidate.
package cidr

import (
	"bytes"
	"net/netip"
	"strconv"
	"testing"
)

func buildNoncoalescingMergedSet(size int) (*IpCidrSet, error) {
	set := NewIpCidrSet()
	for i := 0; i < size; i++ {
		value := i * 2
		addr := netip.AddrFrom4([4]byte{10, byte(value >> 16), byte(value >> 8), byte(value)})
		if err := set.AddIpCidr(netip.PrefixFrom(addr, 32)); err != nil {
			return nil, err
		}
	}
	if err := set.Merge(); err != nil {
		return nil, err
	}
	return set, nil
}

func benchMergedIpCidrSet(b *testing.B, size int) *IpCidrSet {
	b.Helper()
	set, err := buildNoncoalescingMergedSet(size)
	if err != nil {
		b.Fatal(err)
	}
	return set
}

func BenchmarkIpCidrSetWriteBin(b *testing.B) {
	set := benchMergedIpCidrSet(b, 10_000)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		var encoded bytes.Buffer
		if err := set.WriteBin(&encoded); err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkReadIpCidrSet(b *testing.B) {
	set := benchMergedIpCidrSet(b, 10_000)
	var encoded bytes.Buffer
	if err := set.WriteBin(&encoded); err != nil {
		b.Fatal(err)
	}
	payload := encoded.Bytes()
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err := ReadIpCidrSet(bytes.NewReader(payload)); err != nil {
			b.Fatal(err)
		}
	}
}

func BenchmarkIpCidrSetMergedMiss(b *testing.B) {
	for _, size := range []int{1_000, 100_000} {
		b.Run(strconv.Itoa(size), func(b *testing.B) {
			set := benchMergedIpCidrSet(b, size)
			miss := netip.MustParseAddr("192.0.2.1")
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				if set.IsContain(miss) {
					b.Fatal("unexpected match")
				}
			}
		})
	}
}
