// Identical-source A/B harness; generated from the reviewed candidate.
package statistic

import (
	N "github.com/Miku0139oao/aster-core/common/net"
	trafficControl "github.com/Miku0139oao/aster-core/component/trafficcontrol"
	C "github.com/Miku0139oao/aster-core/constant"
	"github.com/stretchr/testify/require"
	"io"
	"net"
	"path/filepath"
	"testing"
	"time"
)

type trackerTestConn struct {
	N.ExtendedConn
}

func (c *trackerTestConn) Chains() C.Chain { return nil }

func (c *trackerTestConn) ProviderChains() C.Chain { return nil }

func (c *trackerTestConn) AppendToChains(C.ProxyAdapter) {}

func (c *trackerTestConn) RemoteDestination() string { return "" }

type discardNetConn struct{}

func (discardNetConn) Read([]byte) (int, error) { return 0, io.EOF }

func (discardNetConn) Write(p []byte) (int, error) { return len(p), nil }

func (discardNetConn) Close() error { return nil }

func (discardNetConn) LocalAddr() net.Addr { return nil }

func (discardNetConn) RemoteAddr() net.Addr { return nil }

func (discardNetConn) SetDeadline(time.Time) error { return nil }

func (discardNetConn) SetReadDeadline(time.Time) error { return nil }

func (discardNetConn) SetWriteDeadline(time.Time) error { return nil }

func newDiscardTrackerConn() C.Conn {
	return &trackerTestConn{ExtendedConn: N.NewExtendedConn(discardNetConn{})}
}

type staticChainConn struct {
	C.Conn
	chain C.Chain
}

func (c *staticChainConn) Chains() C.Chain { return c.chain }

func BenchmarkTCPTrackerLifecycle(b *testing.B) {
	manager := &Manager{}
	conn := &staticChainConn{Conn: newDiscardTrackerConn(), chain: C.Chain{"DIRECT"}}
	metadata := &C.Metadata{NetWork: C.TCP, Type: C.TUN, Host: "example.com", DstPort: 443}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		tracker := NewTCPTracker(conn, manager, metadata, nil, 0, 0, true)
		if err := tracker.Close(); err != nil {
			b.Fatal(err)
		}
	}
}

var (
	sinkReader io.Reader
	sinkWriter io.Writer
	sinkCounts []N.CountFunc
)

func BenchmarkTCPTrackerUnwrapReader(b *testing.B) {
	manager := &Manager{}
	tracker := NewTCPTracker(newDiscardTrackerConn(), manager, &C.Metadata{NetWork: C.TCP, Type: C.TUN}, nil, 0, 0, true)
	b.Cleanup(func() { _ = tracker.Close() })
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		sinkReader, sinkCounts = tracker.UnwrapReader()
	}
}

func configureEnabledTrafficControl(tb testing.TB) {
	tb.Helper()
	config := &trafficControl.Config{
		Enabled:            true,
		StorePath:          filepath.Join(tb.TempDir(), "traffic.db"),
		CheckpointInterval: time.Hour,
		MaxStoreSize:       trafficControl.DefaultStoreLimit,
		Reports: trafficControl.ReportsConfig{
			Enabled:          true,
			HourlyRetention:  trafficControl.DefaultHourlyRetention,
			DailyRetention:   trafficControl.DefaultDailyRetention,
			MonthlyRetention: trafficControl.DefaultMonthlyRetention,
			OrphanRetention:  trafficControl.DefaultOrphanRetention,
		},
		Policies: []trafficControl.Policy{{
			ID:      "global",
			Kind:    trafficControl.PolicyGlobal,
			Enabled: true,
			Quota: trafficControl.QuotaConfig{
				TotalBytes: 1 << 40,
				Window:     time.Hour,
			},
		}},
	}
	require.NoError(tb, trafficControl.Default.Configure(config))
	tb.Cleanup(func() { require.NoError(tb, trafficControl.Default.Configure(nil)) })
}

func BenchmarkTCPTrackerLifecycleTrafficControl(b *testing.B) {
	configureEnabledTrafficControl(b)
	manager := &Manager{}
	conn := &staticChainConn{Conn: newDiscardTrackerConn(), chain: C.Chain{"DIRECT"}}
	metadata := &C.Metadata{NetWork: C.TCP, Type: C.TUN, Host: "example.com", DstPort: 443}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		tracker := NewTCPTracker(conn, manager, metadata, nil, 0, 0, true)
		if err := tracker.Close(); err != nil {
			b.Fatal(err)
		}
	}
}
