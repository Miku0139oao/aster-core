// Identical-source A/B harness; generated from the reviewed candidate.
package common

import (
	C "github.com/Miku0139oao/aster-core/constant"
	"testing"
)

func benchMetadataHost(host string) *C.Metadata {
	return &C.Metadata{Host: host}
}

func BenchmarkDomainSuffixMatch(b *testing.B) {
	rule := NewDomainSuffix("example.com", "DIRECT")
	hitExact := benchMetadataHost("example.com")
	hitSub := benchMetadataHost("www.example.com")
	miss := benchMetadataHost("notexample.com")
	helper := C.RuleMatchHelper{}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = rule.Match(hitExact, helper)
		_, _ = rule.Match(hitSub, helper)
		_, _ = rule.Match(miss, helper)
	}
}

func BenchmarkDomainSuffixMatchMixedCase(b *testing.B) {
	rule := NewDomainSuffix("example.com", "DIRECT")
	hit := benchMetadataHost("WWW.Example.COM")
	helper := C.RuleMatchHelper{}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_, _ = rule.Match(hit, helper)
	}
}

func BenchmarkNewDomainSuffix(b *testing.B) {
	var sink *DomainSuffix
	b.ReportAllocs()
	for i := 0; i < b.N; i++ {
		sink = NewDomainSuffix("example.com", "DIRECT")
	}
	if sink == nil {
		b.Fatal("nil")
	}
}
