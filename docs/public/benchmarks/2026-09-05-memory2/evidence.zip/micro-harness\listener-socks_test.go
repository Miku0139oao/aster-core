// Identical-source A/B harness; generated from the reviewed candidate.
package socks

import (
	"github.com/Miku0139oao/aster-core/adapter/inbound"
	C "github.com/Miku0139oao/aster-core/constant"
	"io"
	"net"
	"testing"
	"time"
)

type stubTunnel struct{}

func (stubTunnel) HandleTCPConn(net.Conn, *C.Metadata) {}

func (stubTunnel) HandleUDPPacket(C.UDPPacket, *C.Metadata) {}

func (stubTunnel) NatTable() C.NatTable { return nil }

type dropUDPTunnel struct{ stubTunnel }

func (dropUDPTunnel) HandleUDPPacket(packet C.UDPPacket, _ *C.Metadata) {
	if packet != nil {
		packet.Drop()
	}
}

type discardPacketConn struct{}

func (discardPacketConn) ReadFrom([]byte) (int, net.Addr, error) { return 0, nil, io.EOF }

func (discardPacketConn) WriteTo(b []byte, _ net.Addr) (int, error) {
	return len(b), nil
}

func (discardPacketConn) Close() error { return nil }

func (discardPacketConn) LocalAddr() net.Addr {
	return &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 1080}
}

func (discardPacketConn) SetDeadline(time.Time) error { return nil }

func (discardPacketConn) SetReadDeadline(time.Time) error { return nil }

func (discardPacketConn) SetWriteDeadline(time.Time) error { return nil }

func BenchmarkHandleSocksUDP(b *testing.B) {
	buf := []byte{
		0, 0, 0,
		1, 1, 2, 3, 4, 0, 53,
		'p', 'a', 'y',
	}
	pc := discardPacketConn{}
	src := &net.UDPAddr{IP: net.IPv4(192, 0, 2, 1), Port: 12345}
	additions := []inbound.Addition{inbound.WithInName("bench-socks")}

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		handleSocksUDP(pc, dropUDPTunnel{}, buf, nil, src, additions...)
	}
}
