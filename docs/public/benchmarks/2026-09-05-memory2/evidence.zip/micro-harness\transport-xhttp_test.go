// Identical-source A/B harness; generated from the reviewed candidate.
package xhttp

import (
	"strconv"
	"testing"
)

func BenchmarkUploadQueueSequential(b *testing.B) {
	for _, size := range []int{1024, 16 * 1024} {
		b.Run(strconv.Itoa(size), func(b *testing.B) {
			q := NewUploadQueue(32, 1<<20)
			payload := make([]byte, size)
			buf := make([]byte, size)
			b.SetBytes(int64(size))
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				if err := q.Push(Packet{Seq: uint64(i), Payload: payload}); err != nil {
					b.Fatal(err)
				}
				n, err := q.Read(buf)
				if err != nil {
					b.Fatal(err)
				}
				if n != size {
					b.Fatalf("short read: %d", n)
				}
			}
		})
	}
}
