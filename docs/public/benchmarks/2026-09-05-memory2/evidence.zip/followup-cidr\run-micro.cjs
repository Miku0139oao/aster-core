const fs=require('fs'),cp=require('child_process'),crypto=require('crypto');
const root=__dirname.replaceAll('\\','/');
const manifest=JSON.parse(fs.readFileSync(root+'/micro-manifest.json','utf8'));
const action=process.argv[2]||'smoke';const requested=process.argv.slice(3);
const env={...process.env,GOMAXPROCS:'1',GOAMD64:'v1'};delete env.GOGC;delete env.GOMEMLIMIT;
function run(binary,args,log){const r=cp.spawnSync(binary,args,{encoding:'utf8',env,timeout:240000,maxBuffer:16*1024*1024});fs.mkdirSync(require('path').dirname(log),{recursive:true});fs.writeFileSync(log,(r.stdout||'')+(r.stderr||''));if(r.error||r.status!==0)throw Error('Benchmark failed '+log+' '+(r.error||r.stderr||r.stdout));return r.stdout}
function hash(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}
function escape(s){return s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}
function regex(name){return name.split('/').map(x=>'^'+escape(x)+'$').join('/')}
const selected=manifest.matrix.filter(x=>!requested.length||requested.includes(x.key));
if(action==='smoke'){
 for(const row of selected){
  if(hash(row.harness)!==row.harnessSha256)throw Error('Harness drift '+row.key);
  const lists=[];const binaries={};
  for(const label of ['before','after']){
   const binary=root+'/micro-bin/'+label+'/'+row.key+'.exe';binaries[label]=hash(binary);
   const text=run(binary,['-test.run=^$','-test.bench=^('+row.names.join('|')+')$','-test.benchtime=1x','-test.count=1','-test.cpu=1'],root+'/micro-smoke/'+label+'-'+row.key+'.txt');
   lists.push([...text.matchAll(/^(Benchmark\S+)\s+\d+\s+\S+ ns\/op/gm)].map(x=>x[1].replace(/-1$/,'')));
  }
  if(JSON.stringify(lists[0])!==JSON.stringify(lists[1])||!lists[0].length)throw Error('Before/after case mismatch '+row.key);
  fs.writeFileSync(root+'/micro-smoke/'+row.key+'-cases.json',JSON.stringify({...row,cases:lists[0],binaries},null,2));
  console.log('SMOKE PASS '+row.key+' '+lists[0].length+' identical cases');
 }
}else if(action==='run'){
 for(const row of selected){
  const cases=JSON.parse(fs.readFileSync(root+'/micro-smoke/'+row.key+'-cases.json','utf8'));
  for(const label of ['before','after']){if(hash(root+'/micro-bin/'+label+'/'+row.key+'.exe')!==cases.binaries[label])throw Error('Binary drift '+row.key)}
  for(let round=1;round<=7;round++){
   const order=round%2?['before','after']:['after','before'];const shift=(round-1)%cases.cases.length;
   const rotated=cases.cases.slice(shift).concat(cases.cases.slice(0,shift));
   for(const name of rotated){for(const label of order){
    const log=root+'/micro-raw/'+row.key+'/'+name.replaceAll('/','__')+'/'+round+'-'+label+'.txt';
    if(fs.existsSync(log))throw Error('Refusing duplicate/overwrite sample '+log);
    run(root+'/micro-bin/'+label+'/'+row.key+'.exe',['-test.run=^$','-test.bench='+regex(name),'-test.benchtime=2s','-test.count=1','-test.cpu=1'],log);
   }}
   console.log(row.key+' round '+round+'/7 complete');
  }
 }
}else{throw Error('unknown action')}
