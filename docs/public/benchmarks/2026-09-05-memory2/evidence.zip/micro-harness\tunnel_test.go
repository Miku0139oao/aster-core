// Identical-source A/B harness; generated from the reviewed candidate.
package tunnel

import (
	N "github.com/Miku0139oao/aster-core/common/net"
	C "github.com/Miku0139oao/aster-core/constant"
	"github.com/Miku0139oao/aster-core/tunnel/statistic"
	"io"
	"net"
	"net/netip"
	"strconv"
	"testing"
)

type relayBenchmarkConn struct {
	N.ExtendedConn
}

func (*relayBenchmarkConn) Chains() C.Chain { return nil }

func (*relayBenchmarkConn) ProviderChains() C.Chain { return nil }

func (*relayBenchmarkConn) AppendToChains(C.ProxyAdapter) {}

func (*relayBenchmarkConn) RemoteDestination() string { return "benchmark" }

func (c *relayBenchmarkConn) UpstreamReader() any { return c.ExtendedConn }

func (c *relayBenchmarkConn) UpstreamWriter() any { return c.ExtendedConn }

func (*relayBenchmarkConn) ReaderReplaceable() bool { return true }

func (*relayBenchmarkConn) WriterReplaceable() bool { return true }

func BenchmarkPacketSenderMappingInsert(b *testing.B) {
	for _, count := range []int{1, 2, 100, 1000} {
		b.Run(strconv.Itoa(count), func(b *testing.B) {
			b.ReportAllocs()
			for i := 0; i < b.N; i++ {
				sender := newPacketSender().(*packetSender)
				for j := 0; j < count; j++ {
					origin := &C.Metadata{DstIP: netip.AddrFrom4([4]byte{10, byte(j >> 16), byte(j >> 8), byte(j)}), DstPort: uint16(j)}
					target := &C.Metadata{DstIP: netip.AddrFrom4([4]byte{11, byte(j >> 16), byte(j >> 8), byte(j)}), DstPort: uint16(j)}
					if !sender.addMapping(origin, target) {
						b.Fatal("mapping limit reached")
					}
				}
				sender.Close()
			}
		})
	}
}

func BenchmarkPacketSenderDestinationLookup(b *testing.B) {
	sender := newPacketSender().(*packetSender)
	b.Cleanup(sender.Close)
	origin := &C.Metadata{DstIP: netip.MustParseAddr("192.0.2.1")}
	target := &C.Metadata{DstIP: netip.MustParseAddr("198.51.100.1")}
	sender.AddMapping(origin, target)

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if got := sender.targetAddress(origin); got == nil || got.AddrPort() != target.AddrPort() {
			b.Fatalf("unexpected target: %v", got)
		}
	}
}

func BenchmarkTCPRelayThroughput(b *testing.B) {
	sourceWriter, sourceRelay := net.Pipe()
	destinationRelay, destinationReader := net.Pipe()
	manager := &statistic.Manager{}
	metadata := &C.Metadata{NetWork: C.TCP, Type: C.TUN, Host: "example.com", DstPort: 443}
	remote := &relayBenchmarkConn{ExtendedConn: N.NewExtendedConn(destinationRelay)}
	tracker := statistic.NewTCPTracker(remote, manager, metadata, nil, 0, 0, true)
	payload := make([]byte, 32*1024)
	total := int64(b.N) * int64(len(payload))
	copyDone := make(chan error, 1)
	go func() {
		_, err := io.CopyN(io.Discard, destinationReader, total)
		copyDone <- err
	}()
	relayDone := make(chan struct{})
	go func() {
		handleSocket(sourceRelay, tracker)
		close(relayDone)
	}()

	b.ReportAllocs()
	b.SetBytes(int64(len(payload)))
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err := sourceWriter.Write(payload); err != nil {
			b.Fatal(err)
		}
	}
	b.StopTimer()
	_ = sourceWriter.Close()
	if err := <-copyDone; err != nil {
		b.Fatal(err)
	}
	_ = destinationReader.Close()
	<-relayDone
	if uploaded, _ := manager.Total(); uploaded != total {
		b.Fatalf("tracked upload = %d, want %d", uploaded, total)
	}
}
