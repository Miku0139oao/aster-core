// Identical-source A/B harness; generated from the reviewed candidate.
package net

import (
	"bytes"
	stdnet "net"
	"testing"
)

type testReaderConn struct {
	stdnet.Conn
	*bytes.Reader
}

func (c *testReaderConn) Read(p []byte) (int, error) {
	return c.Reader.Read(p)
}

func (*testReaderConn) Close() error { return nil }

func BenchmarkNewBufferedConn(b *testing.B) {
	payload := []byte("0123456789abcdef")
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		conn := NewBufferedConn(&testReaderConn{Reader: bytes.NewReader(payload)})
		_, _ = conn.Peek(1)
		if cached := conn.ReadCached(); cached != nil {
			cached.Release()
		}
		if empty := conn.ReadCached(); empty != nil {
			empty.Release()
		}
	}
}

func BenchmarkReadCachedDrainRelease(b *testing.B) {
	payload := []byte("0123456789abcdef")
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		conn := NewBufferedConn(&testReaderConn{Reader: bytes.NewReader(payload)})
		_, _ = conn.Peek(len(payload))
		cached := conn.ReadCached()
		if cached != nil {
			cached.Release()
		}
		if empty := conn.ReadCached(); empty != nil {
			empty.Release()
		}
	}
}
