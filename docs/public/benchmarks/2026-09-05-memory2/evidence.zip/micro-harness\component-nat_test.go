// Identical-source A/B harness; generated from the reviewed candidate.
package nat

import (
	C "github.com/Miku0139oao/aster-core/constant"
	"net/netip"
	"testing"
)

type benchmarkPacketSender struct {
	C.PacketSender
}

func BenchmarkTableExistingFlow(b *testing.B) {
	table := New()
	key := C.UDPNatKey{AddrPort: netip.MustParseAddrPort("192.0.2.1:12345")}
	sender := &benchmarkPacketSender{}
	maker := func() C.PacketSender { return sender }
	if _, loaded, admitted := table.GetOrCreate(key, maker); loaded || !admitted {
		b.Fatal("first lookup unexpectedly loaded")
	}
	if _, loaded, admitted := table.GetOrCreate(key, maker); !loaded || !admitted {
		b.Fatal("failed to prime NAT last-hit cache")
	}

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		got, loaded, admitted := table.GetOrCreate(key, maker)
		if !loaded || !admitted || got != sender {
			b.Fatal("existing NAT flow was not found")
		}
	}
}

func BenchmarkTableFill4096(b *testing.B) {
	maker := func() C.PacketSender { return &benchmarkPacketSender{} }
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		table := New()
		for j := 0; j < 4096; j++ {
			key := C.UDPNatKey{AddrPort: netip.AddrPortFrom(netip.AddrFrom4([4]byte{10, byte(j >> 16), byte(j >> 8), byte(j)}), uint16(j+1))}
			if _, loaded, admitted := table.GetOrCreate(key, maker); loaded || !admitted {
				b.Fatal("fill lookup failed")
			}
		}
	}
}
