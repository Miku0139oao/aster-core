// Identical-source A/B harness; generated from the reviewed candidate.
package dns

import (
	"context"
	"encoding/binary"
	D "github.com/miekg/dns"
	"io"
	"net"
	"sync"
	"testing"
	"time"
)

type staticDNSClient struct {
	aDelay, aaaaDelay time.Duration
	a, aaaa           []net.IP
}

func (c *staticDNSClient) ExchangeContext(ctx context.Context, m *D.Msg) (*D.Msg, error) {
	q := m.Question[0]
	var delay time.Duration
	var ips []net.IP
	switch q.Qtype {
	case D.TypeA:
		delay, ips = c.aDelay, c.a
	case D.TypeAAAA:
		delay, ips = c.aaaaDelay, c.aaaa
	default:
		msg := new(D.Msg)
		msg.SetRcode(m, D.RcodeNameError)
		return msg, nil
	}
	if delay > 0 {
		select {
		case <-time.After(delay):
		case <-ctx.Done():
			return nil, ctx.Err()
		}
	}
	msg := new(D.Msg)
	msg.SetReply(m)
	for _, ip := range ips {
		switch q.Qtype {
		case D.TypeA:
			msg.Answer = append(msg.Answer, &D.A{
				Hdr: D.RR_Header{Name: q.Name, Rrtype: D.TypeA, Class: D.ClassINET, Ttl: 60},
				A:   ip,
			})
		case D.TypeAAAA:
			msg.Answer = append(msg.Answer, &D.AAAA{
				Hdr:  D.RR_Header{Name: q.Name, Rrtype: D.TypeAAAA, Class: D.ClassINET, Ttl: 60},
				AAAA: ip,
			})
		}
	}
	return msg, nil
}

func (c *staticDNSClient) Address() string { return "static" }

func (c *staticDNSClient) ResetConnection() {}

func testResolver(client dnsClient, ipv6Timeout time.Duration) *Resolver {
	return &Resolver{
		ipv6:        true,
		ipv6Timeout: ipv6Timeout,
		main:        []dnsClient{client},
		cache:       Config{}.newCache(),
	}
}

func cachedAResolver(t testing.TB) (*Resolver, *D.Msg) {
	t.Helper()
	client := &staticDNSClient{a: []net.IP{net.ParseIP("192.0.2.1").To4()}}
	r := testResolver(client, 50*time.Millisecond)
	req := new(D.Msg)
	req.SetQuestion("warm.example.", D.TypeA)
	if _, err := r.ExchangeContext(context.Background(), req); err != nil {
		t.Fatalf("warm cache: %v", err)
	}
	return r, req
}

func BenchmarkGetMsgFromCacheHit(b *testing.B) {
	cache := Config{}.newCache()
	req := new(D.Msg)
	req.SetQuestion("example.com.", D.TypeA)
	resp := new(D.Msg)
	resp.SetReply(req)
	resp.Answer = []D.RR{&D.A{
		Hdr: D.RR_Header{Name: "example.com.", Rrtype: D.TypeA, Class: D.ClassINET, Ttl: 300},
		A:   net.IPv4(192, 0, 2, 1).To4(),
	}}
	putMsgToCache(cache, req.Question[0], resp)

	q := req.Question[0]
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		msg, _, hit := getMsgFromCache(cache, q)
		if !hit || msg == nil {
			b.Fatal("cache miss")
		}
	}
}

func BenchmarkLookupIPv4CacheHit(b *testing.B) {
	r, _ := cachedAResolver(b)
	ctx := context.Background()
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		ips, err := r.LookupIPv4(ctx, "warm.example")
		if err != nil || len(ips) != 1 {
			b.Fatalf("LookupIPv4: %v %v", ips, err)
		}
	}
}

func newAQuestion() *D.Msg {
	m := new(D.Msg)
	m.SetQuestion("www.example.com.", D.TypeA)
	m.Id = 0x1234
	m.RecursionDesired = true
	return m
}

func BenchmarkDoTExchangeWithConn(b *testing.B) {
	req := newAQuestion()
	resp := new(D.Msg)
	resp.SetReply(req)
	resp.Answer = []D.RR{
		&D.A{
			Hdr: D.RR_Header{Name: "www.example.com.", Rrtype: D.TypeA, Class: D.ClassINET, Ttl: 60},
			A:   net.IPv4(93, 184, 216, 34),
		},
	}
	packedResp, err := resp.Pack()
	if err != nil {
		b.Fatal(err)
	}

	clientConn, serverConn := net.Pipe()
	defer clientConn.Close()
	defer serverConn.Close()

	var wg sync.WaitGroup
	wg.Add(1)
	go func() {
		defer wg.Done()
		var hdr [2]byte
		buf := make([]byte, 4096)
		for {
			if _, err := io.ReadFull(serverConn, hdr[:]); err != nil {
				return
			}
			n := int(binary.BigEndian.Uint16(hdr[:]))
			if _, err := io.ReadFull(serverConn, buf[:n]); err != nil {
				return
			}
			binary.BigEndian.PutUint16(hdr[:], uint16(len(packedResp)))
			if _, err := serverConn.Write(hdr[:]); err != nil {
				return
			}
			if _, err := serverConn.Write(packedResp); err != nil {
				return
			}
		}
	}()

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		msg, err := exchangeLengthPrefixedConn(clientConn, req, 5*time.Second)
		if err != nil {
			b.Fatal(err)
		}
		if msg == nil || len(msg.Answer) != 1 {
			b.Fatal("missing answer")
		}
	}
	b.StopTimer()
	clientConn.Close()
	wg.Wait()
}
