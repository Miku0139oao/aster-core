// Identical-source A/B harness; generated from the reviewed candidate.
package deadline

import (
	"testing"
	"time"
)

func BenchmarkPipeDeadlineSetRefresh(b *testing.B) {
	d := MakePipeDeadline()
	d.Set(time.Now().Add(time.Hour))
	b.Cleanup(func() { d.Set(time.Time{}) })
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		d.Set(time.Now().Add(time.Hour))
	}
}
