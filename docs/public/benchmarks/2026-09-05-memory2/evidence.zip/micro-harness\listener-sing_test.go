// Identical-source A/B harness; generated from the reviewed candidate.
package sing

import (
	"context"
	C "github.com/Miku0139oao/aster-core/constant"
	"github.com/metacubex/sing/common/buf"
	M "github.com/metacubex/sing/common/metadata"
	"github.com/metacubex/sing/common/network"
	"net"
	"net/netip"
	"testing"
)

type stubTunnel struct{}

func (stubTunnel) HandleTCPConn(net.Conn, *C.Metadata) {}

func (stubTunnel) HandleUDPPacket(C.UDPPacket, *C.Metadata) {}

func (stubTunnel) NatTable() C.NatTable { return nil }

func BenchmarkHandlePacket(b *testing.B) {
	h := &ListenerHandler{ListenerConfig: ListenerConfig{
		Tunnel: stubTunnel{},
		Type:   C.SOCKS5,
	}}
	src := M.SocksaddrFrom(netip.MustParseAddr("192.0.2.1"), 12345)
	dst := M.SocksaddrFrom(netip.MustParseAddr("198.51.100.1"), 443)
	inAddr := &net.UDPAddr{IP: net.IPv4(127, 0, 0, 1), Port: 1080}
	ctx := context.Background()

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		pkt := &packet{lAddr: inAddr}
		h.handlePacket(ctx, pkt, src, dst)
		pkt.Drop()
	}
}

type dropWriteBackWriter struct{}

func (dropWriteBackWriter) WriteTo(p []byte, _ net.Addr) (int, error) {
	return len(p), nil
}

func (dropWriteBackWriter) WritePacket(*buf.Buffer, M.Socksaddr) error {
	return nil
}

func BenchmarkNewPacket(b *testing.B) {
	h := &ListenerHandler{ListenerConfig: ListenerConfig{
		Tunnel: dropUDPTunnel{},
		Type:   C.TUN,
	}}
	src := M.SocksaddrFrom(netip.MustParseAddr("192.0.2.1"), 12345)
	dst := M.SocksaddrFrom(netip.MustParseAddr("198.51.100.1"), 443)
	meta := M.Metadata{Source: src, Destination: dst}
	key := netip.MustParseAddrPort("192.0.2.1:12345")
	writer := dropWriteBackWriter{}
	init := func(network.PacketConn) network.PacketWriter { return writer }
	ctx := context.Background()

	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		buff := buf.NewPacket()
		_, _ = buff.Write([]byte("x"))
		h.NewPacket(ctx, key, buff, meta, init)
	}
}

type dropUDPTunnel struct{}

func (dropUDPTunnel) HandleTCPConn(net.Conn, *C.Metadata) {}

func (dropUDPTunnel) HandleUDPPacket(packet C.UDPPacket, _ *C.Metadata) {
	if packet != nil {
		packet.Drop()
	}
}

func (dropUDPTunnel) NatTable() C.NatTable { return nil }
